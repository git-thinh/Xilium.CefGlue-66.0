﻿namespace Xilium.CefGlue
{
    using System;

    public enum CefRuntimePlatform
    {
        Windows,
        Linux,
        MacOSX,
    }
}
