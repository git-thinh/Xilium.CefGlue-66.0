﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Xilium.CefGlue.WPF
{
    public delegate void LoadEndEventHandler(object sender, LoadEndEventArgs e);
}
