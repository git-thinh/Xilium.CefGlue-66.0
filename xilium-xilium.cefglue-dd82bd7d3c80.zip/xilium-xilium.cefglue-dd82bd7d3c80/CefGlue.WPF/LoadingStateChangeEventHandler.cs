﻿
namespace Xilium.CefGlue.WPF
{
    public delegate void LoadingStateChangeEventHandler(object sender, LoadingStateChangeEventArgs e);
}
